# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.25)
# Database: base_app
# Generation Time: 2015-02-11 14:12:31 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table core_menu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_menu`;

CREATE TABLE `core_menu` (
  `menu_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `menu_slug` varchar(255) DEFAULT NULL,
  `menu_desc` varchar(255) DEFAULT NULL,
  `menu_url` varchar(255) DEFAULT NULL,
  `menu_order` int(2) NOT NULL,
  `menu_st` varchar(255) DEFAULT NULL,
  `menu_display` varchar(255) DEFAULT NULL,
  `menu_icon` varchar(50) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_menu` WRITE;
/*!40000 ALTER TABLE `core_menu` DISABLE KEYS */;

INSERT INTO `core_menu` (`menu_id`, `portal_id`, `parent_id`, `menu_name`, `menu_slug`, `menu_desc`, `menu_url`, `menu_order`, `menu_st`, `menu_display`, `menu_icon`, `creator`, `dc`, `du`)
VALUES
	(1,1,0,'Configuration','configuration',NULL,'',0,'show','yes','glyphicons glyphicons-home',1,NULL,NULL),
	(2,1,1,'Portal','portal',NULL,'base/setting/portal',0,'show','yes','fa fa-flag',1,NULL,NULL),
	(3,1,1,'Menu','menu',NULL,'base/setting/menu',0,'show','yes','glyphicon glyphicon-align-justify',1,NULL,NULL),
	(4,1,1,'User','user',NULL,'base/setting/user',0,'show','yes','glyphicon glyphicon-user',1,NULL,NULL),
	(5,1,1,'Role','role',NULL,'base/setting/role',0,'show','yes','glyphicons glyphicons-group',1,NULL,NULL),
	(6,1,1,'Permission','permission',NULL,'base/setting/permission',0,'show','yes','fa fa-key',NULL,NULL,NULL);

/*!40000 ALTER TABLE `core_menu` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_permission`;

CREATE TABLE `core_permission` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `permission` char(4) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_permission` WRITE;
/*!40000 ALTER TABLE `core_permission` DISABLE KEYS */;

INSERT INTO `core_permission` (`role_id`, `menu_id`, `permission`)
VALUES
	(1,1,'1111'),
	(1,2,'1111'),
	(1,3,'1111'),
	(1,4,'1111'),
	(1,5,'1111'),
	(1,6,'1111');

/*!40000 ALTER TABLE `core_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_portal
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_portal`;

CREATE TABLE `core_portal` (
  `portal_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_name` varchar(255) DEFAULT NULL,
  `portal_slug` varchar(255) DEFAULT NULL,
  `portal_title` varchar(255) DEFAULT NULL,
  `portal_desc` text,
  `creator` int(11) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_portal` WRITE;
/*!40000 ALTER TABLE `core_portal` DISABLE KEYS */;

INSERT INTO `core_portal` (`portal_id`, `portal_name`, `portal_slug`, `portal_title`, `portal_desc`, `creator`, `dc`, `du`)
VALUES
	(1,'Administrator Portal','administrator_portal','Administrator Portal Management','-',1,NULL,NULL);

/*!40000 ALTER TABLE `core_portal` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_role`;

CREATE TABLE `core_role` (
  `role_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_id` int(11) DEFAULT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `role_desc` text,
  `role_default_url` varchar(255) DEFAULT NULL,
  `role_st` varchar(20) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_role` WRITE;
/*!40000 ALTER TABLE `core_role` DISABLE KEYS */;

INSERT INTO `core_role` (`role_id`, `portal_id`, `role_name`, `role_desc`, `role_default_url`, `role_st`, `creator`, `dc`, `du`)
VALUES
	(1,1,'Administrator','-','user/dashboard/','unlock',NULL,NULL,NULL);

/*!40000 ALTER TABLE `core_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_role_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_role_user`;

CREATE TABLE `core_role_user` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_role_user` WRITE;
/*!40000 ALTER TABLE `core_role_user` DISABLE KEYS */;

INSERT INTO `core_role_user` (`role_id`, `user_id`)
VALUES
	(1,1);

/*!40000 ALTER TABLE `core_role_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_user`;

CREATE TABLE `core_user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT NULL,
  `user_pass` varchar(255) DEFAULT NULL,
  `user_key` int(11) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_full_name` varchar(100) DEFAULT NULL,
  `user_address` text,
  `user_birthday` date DEFAULT NULL,
  `user_picture` varchar(255) DEFAULT NULL,
  `user_phone` int(12) DEFAULT NULL,
  `user_st` varchar(20) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_user` WRITE;
/*!40000 ALTER TABLE `core_user` DISABLE KEYS */;

INSERT INTO `core_user` (`user_id`, `user_name`, `user_pass`, `user_key`, `user_email`, `user_full_name`, `user_address`, `user_birthday`, `user_picture`, `user_phone`, `user_st`, `dc`, `du`)
VALUES
	(1,'admin','76350372a8df088856ed83ebe363e9ded095b6b3',NULL,'admin@admin.com','Administrator',NULL,NULL,NULL,NULL,'unlock',NULL,NULL),
	(2,'user_test','76350372a8df088856ed83ebe363e9ded095b6b3',NULL,NULL,'user_test',NULL,NULL,NULL,NULL,NULL,NULL,NULL);

/*!40000 ALTER TABLE `core_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_user_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_user_log`;

CREATE TABLE `core_user_log` (
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `leave_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_user_log` WRITE;
/*!40000 ALTER TABLE `core_user_log` DISABLE KEYS */;

INSERT INTO `core_user_log` (`user_id`, `ip_address`, `visit_date`, `leave_date`)
VALUES
	(1,'127.0.0.1','2015-02-08 01:01:40',NULL),
	(1,'127.0.0.1','2015-02-08 01:22:14',NULL),
	(1,'127.0.0.1','2015-02-08 01:23:05',NULL),
	(1,'127.0.0.1','2015-02-08 02:08:49',NULL),
	(1,'127.0.0.1','2015-02-08 08:01:19',NULL),
	(1,'127.0.0.1','2015-02-08 09:34:41',NULL),
	(1,'127.0.0.1','2015-02-08 09:39:29',NULL),
	(1,'127.0.0.1','2015-02-08 09:44:11',NULL),
	(1,'127.0.0.1','2015-02-08 09:55:30',NULL),
	(1,'127.0.0.1','2015-02-08 09:57:46',NULL),
	(1,'127.0.0.1','2015-02-08 09:58:55',NULL),
	(1,'127.0.0.1','2015-02-09 08:45:01',NULL),
	(1,'127.0.0.1','2015-02-09 10:33:27',NULL),
	(1,'127.0.0.1','2015-02-09 10:11:46',NULL),
	(1,'127.0.0.1','2015-02-11 06:50:30',NULL);

/*!40000 ALTER TABLE `core_user_log` ENABLE KEYS */;
UNLOCK TABLES;



/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
