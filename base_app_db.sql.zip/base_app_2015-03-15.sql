# ************************************************************
# Sequel Pro SQL dump
# Version 4096
#
# http://www.sequelpro.com/
# http://code.google.com/p/sequel-pro/
#
# Host: 127.0.0.1 (MySQL 5.5.25)
# Database: base_app
# Generation Time: 2015-03-15 03:26:03 +0000
# ************************************************************


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


# Dump of table core_menu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_menu`;

CREATE TABLE `core_menu` (
  `menu_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `menu_slug` varchar(255) DEFAULT NULL,
  `menu_desc` varchar(255) DEFAULT NULL,
  `menu_url` varchar(255) DEFAULT NULL,
  `menu_order` int(2) NOT NULL,
  `menu_st` varchar(255) DEFAULT NULL,
  `menu_display` varchar(255) DEFAULT NULL,
  `menu_icon` varchar(50) DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_menu` WRITE;
/*!40000 ALTER TABLE `core_menu` DISABLE KEYS */;

INSERT INTO `core_menu` (`menu_id`, `portal_id`, `parent_id`, `menu_name`, `menu_slug`, `menu_desc`, `menu_url`, `menu_order`, `menu_st`, `menu_display`, `menu_icon`, `creator`, `dc`, `du`)
VALUES
	(1,1,0,'Manajemen User',NULL,NULL,'',1,'active','yes','',1,NULL,NULL),
	(2,1,1,'Portal','portal','test desc','admin/user_management/portal',1,'active','yes','fa fa-flag',1,NULL,NULL),
	(4,1,1,'User','user',NULL,'admin/user_management/user',2,'active','yes','glyphicon glyphicon-user',1,NULL,NULL),
	(5,1,1,'Role','role',NULL,'admin/user_management/role',3,'active','yes','glyphicons glyphicons-group',1,NULL,NULL),
	(7,1,0,'Manajemen Menu',NULL,NULL,NULL,2,'active','yes','',1,NULL,NULL),
	(8,1,7,'Menu',NULL,NULL,'admin/menu_management/menu',1,'active','yes','fa fa-list',1,NULL,NULL),
	(9,1,0,'System',NULL,'','',3,'active','yes','',1,NULL,NULL),
	(10,1,9,'Modul',NULL,NULL,'admin/configuration/module',1,'active','yes','fa fa-puzzle-piece',1,NULL,NULL);

/*!40000 ALTER TABLE `core_menu` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_modules
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_modules`;

CREATE TABLE `core_modules` (
  `module_id` int(100) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(100) NOT NULL DEFAULT '',
  `module_st` tinyint(1) NOT NULL,
  `parent_id` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`module_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_modules` WRITE;
/*!40000 ALTER TABLE `core_modules` DISABLE KEYS */;

INSERT INTO `core_modules` (`module_id`, `module_name`, `module_st`, `parent_id`)
VALUES
	(1,'SI Pelayanan Pasien',1,'0'),
	(2,'Registrasi',1,'1'),
	(3,'Rawat Inap',1,'1'),
	(4,'Rawat Jalan',1,'1'),
	(5,'SI Farmasi',1,'0'),
	(6,'Pengendalian Stok',1,'5'),
	(7,'Gudang Obat',1,'5');

/*!40000 ALTER TABLE `core_modules` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_permission
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_permission`;

CREATE TABLE `core_permission` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `permission` char(4) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_permission` WRITE;
/*!40000 ALTER TABLE `core_permission` DISABLE KEYS */;

INSERT INTO `core_permission` (`role_id`, `menu_id`, `permission`)
VALUES
	(1,1,'1111'),
	(1,2,'1111'),
	(1,3,'1111'),
	(1,4,'1111'),
	(1,5,'1111'),
	(1,6,'1111'),
	(1,8,'1111');

/*!40000 ALTER TABLE `core_permission` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_portal
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_portal`;

CREATE TABLE `core_portal` (
  `portal_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_name` varchar(255) DEFAULT NULL,
  `portal_slug` varchar(255) DEFAULT NULL,
  `portal_title` varchar(255) DEFAULT NULL,
  `portal_desc` text,
  `creator` int(11) DEFAULT NULL,
  `dc` datetime DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`portal_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_portal` WRITE;
/*!40000 ALTER TABLE `core_portal` DISABLE KEYS */;

INSERT INTO `core_portal` (`portal_id`, `portal_name`, `portal_slug`, `portal_title`, `portal_desc`, `creator`, `dc`, `du`)
VALUES
	(1,'Administrator Portal','administrator_portal','Administrator Portal Management','-',1,NULL,NULL);

/*!40000 ALTER TABLE `core_portal` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_role
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_role`;

CREATE TABLE `core_role` (
  `role_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `portal_id` int(11) DEFAULT NULL,
  `role_name` varchar(255) DEFAULT NULL,
  `role_desc` text,
  `role_default_url` varchar(255) DEFAULT NULL,
  `role_st` enum('active','inactive','deleted') DEFAULT NULL,
  `creator` int(11) DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_role` WRITE;
/*!40000 ALTER TABLE `core_role` DISABLE KEYS */;

INSERT INTO `core_role` (`role_id`, `portal_id`, `role_name`, `role_desc`, `role_default_url`, `role_st`, `creator`, `dc`, `du`)
VALUES
	(1,1,'Administrator','Portal administrator.','admin/','active',NULL,NULL,NULL);

/*!40000 ALTER TABLE `core_role` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_role_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_role_user`;

CREATE TABLE `core_role_user` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_role_user` WRITE;
/*!40000 ALTER TABLE `core_role_user` DISABLE KEYS */;

INSERT INTO `core_role_user` (`role_id`, `user_id`)
VALUES
	(1,1),
	(2,13);

/*!40000 ALTER TABLE `core_role_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_user
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_user`;

CREATE TABLE `core_user` (
  `user_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_name` varchar(255) DEFAULT '',
  `user_pass` varchar(255) DEFAULT NULL,
  `user_key` int(11) DEFAULT NULL,
  `user_email` varchar(255) DEFAULT NULL,
  `user_full_name` varchar(100) DEFAULT NULL,
  `user_address` text,
  `user_birthday` date DEFAULT NULL,
  `user_picture` varchar(255) DEFAULT NULL,
  `user_phone` int(12) DEFAULT NULL,
  `user_st` enum('active','inactive','deleted') DEFAULT NULL,
  `dc` timestamp NULL DEFAULT NULL,
  `du` datetime DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

LOCK TABLES `core_user` WRITE;
/*!40000 ALTER TABLE `core_user` DISABLE KEYS */;

INSERT INTO `core_user` (`user_id`, `user_name`, `user_pass`, `user_key`, `user_email`, `user_full_name`, `user_address`, `user_birthday`, `user_picture`, `user_phone`, `user_st`, `dc`, `du`)
VALUES
	(1,'admin','76350372a8df088856ed83ebe363e9ded095b6b3',NULL,'admin@admin.com','Admin','Office','2015-03-09',NULL,85625563,'active','2015-03-01 00:00:00','2015-03-03 18:29:50');

/*!40000 ALTER TABLE `core_user` ENABLE KEYS */;
UNLOCK TABLES;


# Dump of table core_user_log
# ------------------------------------------------------------

DROP TABLE IF EXISTS `core_user_log`;

CREATE TABLE `core_user_log` (
  `user_id` int(11) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `visit_date` datetime DEFAULT NULL,
  `leave_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;




/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
